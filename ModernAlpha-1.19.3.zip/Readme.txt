Creator of Pack: https://www.youtube.com/user/AndroidXiOSGaming
Official Website: https://www.tozinapp.com/

Compatible for 1.16.x

This pack is made entirely by textures made by Mojang, and I do not claim credit for designing any of them, I merely compiled them all into this one texture pack.
Feel free to use this pack in your videos, but please leave a link to my website for the download.
You can remix or recreate this pack however you'd like to.